<?php
    include 'master/adminMenu.php';
    include 'master/categoryList.php';
    include 'master/question.php';
    include 'master/footer.html';
