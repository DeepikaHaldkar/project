<?php
    include 'master/UserMenu.php';
    include 'master/categoryList.php';
    include_once 'master/question.php';
    include 'master/footer.html';
 